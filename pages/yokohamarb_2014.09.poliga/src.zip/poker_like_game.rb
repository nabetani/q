require './version'

# CodeIQ カードゲームの役を判定する (q476) の実装
module PokerLikeGame
  def self.answer?(hand)
    cards = hand.split(',')
    # ランクを集める。
    ranks = []
    cards.each do |c|
      if cards.size == 3
        ranks.push c[1, 2]
      else
        ranks.push c[1, 1]
      end
    end
    # 比較のためにソート
    ranks.sort!
    # 4枚+2枚
    if ranks[0] == ranks[1] && ranks[1] == ranks[2] && ranks[0] == ranks[3] && ranks[4] == ranks[5]
      return true
    end
    # 2枚+4枚
    if ranks[0] == ranks[1] && ranks[5] == ranks[2] && ranks[5] == ranks[3] && ranks[4] == ranks[5]
      return true
    end
    return false
  end

  def self.sdt?(hand)
    cards = hand.split(',')
    # ランクとスートを集める
    ranks = []
    suits = []
    cards.each do |c|
      suits.push c[0]
      if cards.size == 3
        ranks.push c[1, 2]
      else
        ranks.push c[1, 1]
      end
    end
    # 比較のためにソート
    ranks.sort!
    suits.sort!
    # ランクとスートを調査
    if ranks[0] == ranks[1] && ranks[1] == ranks[2] && ranks[5] == ranks[3] && ranks[4] == ranks[5] && suits[0] == suits[1] && suits[2] == suits[3] && suits[4] == suits[5]
      return true
    end
    return false
  end

  def self.dt?(hand)
    cards = hand.split(',')
    # ランクとスートを集める
    ranks = []
    suits = []
    cards.each do |c|
      suits.push c[0]
      if c.size == 3
        ranks.push c[1, 2]
      else
        ranks.push c[1, 1]
      end
    end
    # 比較のためにソート
    ranks.sort!
    suits.sort!
    # ランクのみ比較
    if ranks[0] == ranks[1] && ranks[1] == ranks[2] && ranks[5] == ranks[3] && ranks[4] == ranks[5]
      return true
    end
    return false
  end

  def self.stp?(hand)
    cards = hand.split(',')
    # ランクとスートを集める
    ranks = []
    suits = []
    cards.each do |c|
      suits.push c[0]
      if c.size == 3
        ranks.push c[1, 2]
      else
        ranks.push c[1, 1]
      end
    end
    # 比較のためにソート。
    ranks.sort!
    suits.sort!
    # まずはランクを調査
    if ranks[0] == ranks[1] && ranks[3] == ranks[2] && ranks[5] == ranks[4]
      # ランクごとにスートを集める
      s0, s1, s2 = [], [], []
      cards.each do |c|
        if c.size == 3
          if c[1, 2] == ranks[0]
            s0.push c[0]
          elsif c[1, 2] == ranks[2]
            s1.push c[0]
          elsif c[1, 2] == ranks[4]
            s2.push c[0]
          end
        else
          if c[1, 1] == ranks[0]
            s0.push c[0]
          elsif c[1, 1] == ranks[2]
            s1.push c[0]
          elsif c[1, 1] == ranks[4]
            s2.push c[0]
          end
        end
        # 比較のためにソート
        s0.sort!
        s1.sort!
        s2.sort!
        # スートを調査
        if s0 == s1 && s1 == s2 && s2 == s0
          return true
        end
      end
    end
    return false
  end

  def self.tp?(hand)
    cards = hand.split(',')
    # ランクとスートを集める
    ranks = []
    suits = []
    cards.each do |c|
      suits.push c[0]
      if c.size == 3
        ranks.push c[1, 2]
      else
        ranks.push c[1, 1]
      end
    end
    # 比較のためにソート。
    ranks.sort!
    suits.sort!
    # ランクを調査
    if ranks[0] == ranks[1] && ranks[3] == ranks[2] && ranks[5] == ranks[4]
      return true
    end
  end

  def self.rank_as_int(rank)
    if /\d/=~rank
      return rank.to_i
    end
    case rank
    when 'J'
      return 11
    when 'Q'
      return 12
    when 'K'
      return 13
    when 'A'
      return 1
    end
  end

  def self.ctp?(hand)
    cards = hand.split(',')
    # ランクとスートを集める
    ranks = []
    suits = []
    cards.each do |c|
      suits.push c[0]
      if c.size == 3
        ranks.push c[1, 2]
      else
        ranks.push c[1, 1]
      end
    end
    # 比較のためにソート。
    ranks.sort!
    suits.sort!
    if ranks[0] == ranks[1] && ranks[3] == ranks[2] && ranks[5] == ranks[4]
      r0 = rank_as_int(ranks[0])
      r1 = rank_as_int(ranks[3])
      r2 = rank_as_int(ranks[5])
      if r0 + 1 == r1 && r1 + 1 == r2
        return true
      end
      # QKA 対策
      if r0 == 1 && r1 == 13 && r2 == 12
        return true
      end
      # なぜか変な順序で来る。
      if ( r0 == 10 && r1 == 9 && r2 == 11) || ( r0 == 11 && r1 == 13 && r2 == 12) || ( r0 == 2 && r1 == 3 && r2 == 1)
        return true
      end
    end
  end

  # 役を判定する関数。
  # @param [hand] "S5,D3,C5,S3,H3,C3" のような文字列
  # @return [Symbol] 見つかった役を表すシンボル :An, :sDT など
  # @return [nil] 役がない場合は nil
  def self.identify_hand(hand)
    if answer?(hand)
      return :An
    elsif sdt?(hand)
      return :sDT
    elsif dt?(hand)
      return :DT
    end
    stp = stp?(hand)
    ctp = ctp?(hand)
    if stp && ctp
      return :scTP
    elsif ctp
      return :cTP
    elsif stp
      return :sTP
    elsif tp?(hand)
      return :TP
    else
      return nil
    end
  end
end
