if __FILE__ == $PROGRAM_NAME
  puts `rspec #{__FILE__}`
  exit
end

require './poker_like_game'

describe PokerLikeGame do
  it 'has a version number' do
    expect(PokerLikeGame::VERSION).not_to be nil
  end

  describe '.identify_hand' do
    %w(
      D9,C9,S9,H4,S4,H9
      C9,DK,CK,S9,HK,SK
      D2,C2,D10,H2,C10,S2
      DA,S6,D6,H6,HA,C6
      C2,D8,C8,H8,S8,H2
      D7,DK,SK,CK,HK,C7
      DA,S10,H10,HA,C10,D10
      DK,HK,S6,H6,SK,CK
      H5,D2,H2,C2,D5,S2
      S5,D3,C5,S3,H3,C3
    ).each do |hand|
      it "can identify #{hand} as answer" do
        expect(PokerLikeGame.identify_hand(hand)).to eq(:An)
      end
    end

    %w(
      D5,C3,D3,H5,H3,C5
      H2,C2,S2,S8,H8,C8
      D3,CA,SA,C3,S3,DA
      H10,SJ,DJ,D10,S10,HJ
      D10,D3,S3,C3,C10,S10
      HA,CA,S2,SA,C2,H2
      HJ,C9,H9,D9,DJ,CJ
      H3,H2,D2,S2,D3,S3
      D2,SJ,HJ,H2,DJ,S2
      H6,DA,S6,HA,SA,D6
    ).each do |hand|
      it "can identify #{hand} as sync-double-trio" do
        expect(PokerLikeGame.identify_hand(hand)).to eq(:sDT)
      end
    end

    %w(
      D9,S9,HJ,CJ,DJ,H9
      H4,C5,S5,S4,D5,C4
      HA,DA,H3,CA,C3,S3
      C8,C3,H8,S3,D8,D3
      C3,D8,S8,D3,H3,H8
      C6,D9,H6,S9,H9,D6
      C7,DJ,HJ,CJ,S7,H7
      D9,H2,S2,C9,S9,D2
      HQ,CQ,H8,C8,SQ,D8
      D9,S9,HA,CA,C9,DA
    ).each do |hand|
      it "can identify #{hand} as double-trio" do
        expect(PokerLikeGame.identify_hand(hand)).to eq(:DT)
      end
    end

    %w(
      S2,H2,S3,SA,HA,H3
      DA,SA,DK,DQ,SQ,SK
      H2,C3,H3,HA,CA,C2
      C5,S5,C3,C4,S4,S3
      C9,H9,C10,HJ,H10,CJ
      D9,H10,H9,HJ,D10,DJ
      H6,S5,S6,H5,S7,H7
      C6,C8,H6,C7,H8,H7
      S6,C4,S4,C5,S5,C6
      C6,H6,H7,C7,C8,H8
    ).each do |hand|
      it "can identify #{hand} as sync-cont-triple-pair" do
        expect(PokerLikeGame.identify_hand(hand)).to eq(:scTP)
      end
    end

    %w(
      HJ,S9,H10,H9,SJ,C10
      SA,HK,CK,DA,SQ,HQ
      C2,SA,D2,D3,C3,CA
      C4,S4,H5,C5,H3,D3
      S3,H4,S5,C5,C3,S4
      CK,HQ,SQ,HK,DJ,SJ
      DQ,HK,CJ,SJ,CK,SQ
      DJ,H9,D10,H10,C9,HJ
      S4,H6,S5,H4,S6,D5
      S8,D7,C8,C7,C9,S9
    ).each do |hand|
      it "can identify #{hand} as cont-triple-pair" do
        expect(PokerLikeGame.identify_hand(hand)).to eq(:cTP)
      end
    end

    %w(
      H7,H10,H4,S7,S4,S10
      DA,SA,S2,D2,DK,SK
      C7,H3,C3,HA,H7,CA
      SK,S10,S3,DK,D3,D10
      CK,C7,H7,C5,H5,HK
      SQ,D8,D3,S3,DQ,S8
      C9,D9,DQ,D3,C3,CQ
      C7,H5,CQ,C5,H7,HQ
      D5,C5,D2,C8,D8,C2
      C2,HK,H2,CA,CK,HA
    ).each do |hand|
      it "can identify #{hand} as sync-triple-pair" do
        expect(PokerLikeGame.identify_hand(hand)).to eq(:sTP)
      end
    end

    %w(
      CA,S2,SA,SJ,HJ,H2
      D2,S2,DA,DK,HA,CK
      D3,C3,HQ,D10,CQ,H10
      S6,D9,H8,H9,C6,D8
      D9,D5,CQ,SQ,C5,C9
      SQ,D2,C7,S2,HQ,H7
      H6,S10,C10,S5,C6,H5
      HJ,D7,S2,D2,C7,CJ
      D4,D9,SA,HA,C9,S4
      D7,SQ,D3,HQ,S3,C7
    ).each do |hand|
      it "can identify #{hand} as triple-pair" do
        expect(PokerLikeGame.identify_hand(hand)).to eq(:TP)
      end
    end

    %w(
      S3,H5,S4,SA,C8,SJ
      D3,C10,CK,SJ,CA,DK
      C10,S5,S10,H10,DK,S7
      C10,D10,S10,C6,H10,C8
      D6,D2,H9,C6,D10,C2
      SQ,C6,H6,DQ,D6,H4
      SQ,DJ,H9,C10,D7,D5
      H3,D7,SQ,S5,H9,C9
      SK,D3,S6,H6,C7,C6
      D2,D9,HJ,SJ,DJ,CJ
      C5,C4,S3,H4,D4,H3
    ).each do |hand|
      it "can identify #{hand} as no-hand" do
        expect(PokerLikeGame.identify_hand(hand)).to eq(nil)
      end
    end
  end
end
